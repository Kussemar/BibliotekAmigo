create definer = root@`%` view bib_view as
select `l`.`navn` AS `laanernavn`, `b`.`titel` AS `titel`, `f`.`navn` AS `forfatternavn`
from (((`bibliotek`.`laaner` `l` join `bibliotek`.`udlaan` `u`
        on ((`l`.`laaner_id` = `u`.`laaner_id`))) join `bibliotek`.`bog` `b`
       on ((`u`.`bog_id` = `b`.`bog_id`))) join `bibliotek`.`forfatter` `f`
      on ((`b`.`forfatter_id` = `f`.`forfatter_id`)));

